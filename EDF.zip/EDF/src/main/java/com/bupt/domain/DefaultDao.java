package com.bupt.domain;

import org.springframework.stereotype.Repository;

import com.bupt.dao.HibernateGenericDaoImpl;

@Repository
public class DefaultDao  extends HibernateGenericDaoImpl{

}
