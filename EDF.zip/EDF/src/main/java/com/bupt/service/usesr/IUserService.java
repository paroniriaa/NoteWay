package com.bupt.service.usesr;

import com.bupt.domain.User;

public interface IUserService {

    public User getUserByUserId(String userId)throws Exception;

    public User getUserByUserName(String username)throws Exception;

    public User getUser(String userId, String userPasswd)throws Exception;

    public int getUsersCount()throws Exception;

    public void flush() throws Exception;

    public void saveUser(User user) throws Exception;

}
