package com.bupt.service.converter;

import java.util.HashMap;
import java.util.Map;

import com.bupt.util.ResourceUtil;

public class ConverterContext {

   private static Map<String,AbstractConverter> map = new HashMap<String,AbstractConverter>();

    static {
       OfficeConverter officeConverter = new OfficeConverter();
       map.put("pdf",new PdfConverter());
       map.put("txt",officeConverter);
       map.put("doc",officeConverter);
       map.put("docx",officeConverter);
       map.put("pptx",officeConverter);
       map.put("ppt",officeConverter);
       map.put("xlsx",officeConverter);
       map.put("xls",officeConverter);

    }
    public static String convert(String type,String path,String id) throws Exception{
        if(ResourceUtil.isImg(type)){
            return null;
        }
        return map.get(type).File2Swf(path,id);
    }
}

