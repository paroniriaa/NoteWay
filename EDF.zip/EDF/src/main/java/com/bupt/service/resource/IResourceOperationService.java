package com.bupt.service.resource;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.bupt.domain.Resource;

public interface IResourceOperationService {

    public File uploadResource(MultipartFile file, String userId, StringBuilder resourceId) throws Exception;

    public void downloadResource(String resourceId, HttpServletResponse response) throws Exception;

    public List<Resource> getResources(String type,int limit,String keyword) throws Exception;

    public List<String> query(String keyword) throws Exception;

    public Resource preview(String id)throws Exception;

    public void imgPreview(String resourceId,HttpServletResponse response) throws Exception;
}



