package com.bupt.service.converter;

public class AbstractConverter {

    public String File2Swf(String path,String id) throws Exception{
        return null;
    }
}
