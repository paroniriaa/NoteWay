package com.bupt.filter;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.bupt.webContext.BRWebApplicationContext;
import com.bupt.webContext.WebContextThreadLocal;

public class ProxyFilter implements Filter {

    private ContextFilter contextFilter = null;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        ServletContext sc = filterConfig.getServletContext();
        String webRootPath = sc.getRealPath("/");
        BRWebApplicationContext.setWebRootPath(webRootPath);
        BRWebApplicationContext.setSc(sc);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        WebContextThreadLocal.unbind();
        HttpServletRequest req = (HttpServletRequest) request;
        if (BRWebApplicationContext.getDomain() == null) {
            String url = req.getRequestURL().toString();
            String contextPath = req.getContextPath();
            Pattern pattern = Pattern.compile("(http://.*?)/");
            Matcher matcher = pattern.matcher(url);
            String basePath = null;
            while(matcher.find()){
                basePath = matcher.group(1);
            }
            if(!"".equals(contextPath)){
               basePath+="/"+contextPath;
            }
            BRWebApplicationContext.setDomain(basePath);
        }
        try {
            initContextFilter()
                    .doFilter(request, response, chain);
        } catch (Exception e) {
            this.destroy();
        }
    }

    @Override
    public void destroy() {
        if (contextFilter != null) {
            this.contextFilter.destroy();
            contextFilter = null;
        }
    }

    private ContextFilter initContextFilter() {
        if (this.contextFilter == null) {
            WebApplicationContext webApplicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(BRWebApplicationContext.getSc());
            contextFilter = (ContextFilter) webApplicationContext.getBean("contextFilter");
            contextFilter.init();
        }
        return this.contextFilter;
    }
}
