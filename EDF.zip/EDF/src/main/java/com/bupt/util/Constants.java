package com.bupt.util;

public interface Constants {


    public static final int[] PAGE_SIZE_LIST = {5,10,15,10};

    public static final int PAGE_NO = 1;

    public static final String USER_INFO = "user";

    public static final String BRUSERID = "BRUSERID";

    public static final String  CURRENT_PAGE = "c_p";

    public static final String USERID = "userId";

    public static final String PASSWD = "passwd";

    public static final String LOGINERROR = "error";

    public static final String LOGIN = "login";
    



}
