package com.bupt.webContext;

import com.bupt.domain.User;

public class WebContextThreadLocal {

    private static ThreadLocal<User> currentUser = new ThreadLocal<User>();

    public static void setCurrentUser(User user) {
        currentUser.set(user);
    }

    public static User getCurrentUser() {
        return currentUser.get();
    }

    public static void unbind() {
        currentUser.remove();
    }
}
