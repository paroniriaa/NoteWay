package com.bupt.dao.user;

import com.bupt.dao.IHibernateGenericDao;
import com.bupt.domain.User;

public interface IUserDao extends IHibernateGenericDao<User,String> {
}
