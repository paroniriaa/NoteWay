package com.bupt.dao.user;

import org.springframework.stereotype.Repository;

import com.bupt.dao.HibernateGenericDaoImpl;
import com.bupt.domain.User;

@Repository
public class UserDaoImpl extends HibernateGenericDaoImpl<User,String> implements IUserDao {

}
