package com.bupt.dao.resource;

import com.bupt.dao.IHibernateGenericDao;
import com.bupt.domain.Resource;

public interface IResourceDao extends IHibernateGenericDao<Resource,String> {
}
