package com.bupt.dao.resource;

import org.springframework.stereotype.Repository;

import com.bupt.dao.HibernateGenericDaoImpl;
import com.bupt.domain.Resource;

@Repository
public class ResourceDaoImpl extends HibernateGenericDaoImpl<Resource,String> implements IResourceDao {
}
